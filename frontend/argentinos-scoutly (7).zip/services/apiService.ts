// Interfaz para los datos que vienen de tu API
interface ApiPlayer {
  Jugador: string
  Equipo: string
  valor_mercado: number
  goles_90: number
  regates_realizados_pct: number
  pases_90: number
  asistencias_90: number
  duelos_aereos_ganados_pct: number
  goles_cabeza_90: number
  duelos_atacantes_ganados_pct: number
}

// Interfaz para las estadísticas del radar (sin valor_mercado)
interface PlayerStats {
  goles_90: number
  regates_realizados_pct: number
  pases_90: number
  asistencias_90: number
  duelos_aereos_ganados_pct: number
  goles_cabeza_90: number
  duelos_atacantes_ganados_pct: number
}

interface Player {
  id: number
  name: string
  position: string
  age: number
  goals: number
  assists: number
  matches: number
  rating: number
  marketValue: string
  team: string
  valor_mercado: number // Mantener valor numérico para estadísticas
  stats: PlayerStats // Solo para el radar
}

interface ApiResponse {
  players: Player[]
  searchedPlayer: Player | null
  isFromApi: boolean
  message: string
}

// Mock data en formato de API (FIXED TYPO)
const mockApiPlayers: ApiPlayer[] = [
  {
    Jugador: "Matias Gimenez Rojas",
    Equipo: "Argentinos Juniors",
    valor_mercado: 2500000,
    goles_90: 0.35,
    regates_realizados_pct: 85.0,
    pases_90: 24.0,
    asistencias_90: 0.15,
    duelos_aereos_ganados_pct: 80.0, // FIXED TYPO
    goles_cabeza_90: 0.12,
    duelos_atacantes_ganados_pct: 35.0,
  },
  {
    Jugador: "Alex Luna",
    Equipo: "Argentinos Juniors",
    valor_mercado: 1800000,
    goles_90: 0.12,
    regates_realizados_pct: 78.0,
    pases_90: 45.0,
    asistencias_90: 0.24,
    duelos_aereos_ganados_pct: 75.0,
    goles_cabeza_90: 0.03,
    duelos_atacantes_ganados_pct: 70.0,
  },
  {
    Jugador: "Miguel Merentiel",
    Equipo: "Argentinos Juniors",
    valor_mercado: 3200000,
    goles_90: 0.44,
    regates_realizados_pct: 82.0,
    pases_90: 25.0,
    asistencias_90: 0.09,
    duelos_aereos_ganados_pct: 88.0,
    goles_cabeza_90: 0.15,
    duelos_atacantes_ganados_pct: 40.0,
  },
  {
    Jugador: "Gonzalo Lencina",
    Equipo: "Argentinos Juniors",
    valor_mercado: 1500000,
    goles_90: 0.06,
    regates_realizados_pct: 70.0,
    pases_90: 40.0,
    asistencias_90: 0.03,
    duelos_aereos_ganados_pct: 90.0,
    goles_cabeza_90: 0.03,
    duelos_atacantes_ganados_pct: 92.0,
  },
]

// Mock del jugador buscado (ejemplo genérico)
const createSearchedPlayerMock = (searchTerm: string): ApiPlayer => ({
  Jugador: searchTerm,
  Equipo: "Referencia",
  valor_mercado: 2000000,
  goles_90: 0.25,
  regates_realizados_pct: 75.0,
  pases_90: 30.0,
  asistencias_90: 0.18,
  duelos_aereos_ganados_pct: 70.0,
  goles_cabeza_90: 0.08,
  duelos_atacantes_ganados_pct: 60.0,
})

export class ApiService {
  private static readonly API_BASE_URL = "http://localhost:8038"
  private static readonly TIMEOUT = 10000 // 10 segundos

  // Función para convertir datos de la API al formato del frontend
  private static mapApiPlayerToPlayer(apiPlayer: ApiPlayer, index: number): Player {
    // Formatear valor de mercado
    const formatMarketValue = (value: number): string => {
      if (value >= 1000000) {
        return `€${(value / 1000000).toFixed(1)}M`
      } else if (value >= 1000) {
        return `€${(value / 1000).toFixed(0)}K`
      } else {
        return `€${value.toLocaleString()}`
      }
    }

    // Función helper para asegurar que los valores sean números válidos
    const safeNumber = (value: any): number => {
      const num = Number(value)
      return isNaN(num) ? 0 : num
    }

    // Estadísticas solo para el radar (sin valor_mercado)
    const stats: PlayerStats = {
      goles_90: safeNumber(apiPlayer.goles_90),
      regates_realizados_pct: safeNumber(apiPlayer.regates_realizados_pct),
      pases_90: safeNumber(apiPlayer.pases_90),
      asistencias_90: safeNumber(apiPlayer.asistencias_90),
      duelos_aereos_ganados_pct: safeNumber(apiPlayer.duelos_aereos_ganados_pct),
      goles_cabeza_90: safeNumber(apiPlayer.goles_cabeza_90),
      duelos_atacantes_ganados_pct: safeNumber(apiPlayer.duelos_atacantes_ganados_pct),
    }

    // Calcular rating basado en estadísticas
    const calculateRating = (): number => {
      const goalsWeight = safeNumber(apiPlayer.goles_90) * 3
      const assistsWeight = safeNumber(apiPlayer.asistencias_90) * 2
      const passesWeight = safeNumber(apiPlayer.pases_90) * 0.1
      const baseRating = 5.0

      return Math.min(10, Math.max(1, baseRating + goalsWeight + assistsWeight + passesWeight))
    }

    return {
      id: index + 1,
      name: apiPlayer.Jugador || "Jugador Desconocido",
      position: "Jugador", // Tu API no incluye posición específica
      age: 25, // Tu API no incluye edad, usar valor por defecto
      goals: Math.round(safeNumber(apiPlayer.goles_90) * 34), // Aproximar goles en temporada (34 partidos promedio)
      assists: Math.round(safeNumber(apiPlayer.asistencias_90) * 34), // Aproximar asistencias
      matches: 34, // Valor por defecto para temporada
      rating: Number(calculateRating().toFixed(1)),
      marketValue: formatMarketValue(safeNumber(apiPlayer.valor_mercado)),
      team: apiPlayer.Equipo || "Equipo Desconocido",
      valor_mercado: safeNumber(apiPlayer.valor_mercado), // Mantener valor numérico
      stats: stats, // Solo para el radar
    }
  }

  // Verificar si la API está disponible
  static async checkApiHealth(): Promise<boolean> {
    try {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 5000)

      const response = await fetch(`${this.API_BASE_URL}/health`, {
        method: "GET",
        signal: controller.signal,
      })

      clearTimeout(timeoutId)
      return response.ok
    } catch (error) {
      console.warn("❌ API no disponible:", error)
      return false
    }
  }

  // Buscar jugadores similares
  static async searchPlayers(playerName: string): Promise<ApiResponse> {
    console.log(`🚀 Buscando jugadores similares a "${playerName}" en ${this.API_BASE_URL}/search-player`)

    try {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), this.TIMEOUT)

      const response = await fetch(`${this.API_BASE_URL}/search-player?name=${encodeURIComponent(playerName)}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      }

      const apiPlayers: ApiPlayer[] = await response.json()
      console.log("✅ Respuesta exitosa de la API:", apiPlayers)

      // Convertir datos de la API al formato del frontend
      const players: Player[] = apiPlayers.map((apiPlayer, index) => this.mapApiPlayerToPlayer(apiPlayer, index))

      // Crear jugador buscado (en una API real, esto vendría del backend)
      const searchedPlayerMock = createSearchedPlayerMock(playerName)
      const searchedPlayer = this.mapApiPlayerToPlayer(searchedPlayerMock, 0)

      return {
        players: players,
        searchedPlayer: searchedPlayer,
        isFromApi: true,
        message: `Encontré ${players.length} jugadores similares a "${playerName}": ${players.map((p) => p.name).join(", ")}`,
      }
    } catch (error) {
      console.warn("⚠️ Error conectando con la API, usando datos mock:", error)

      // Simular delay para que se sienta como una API real
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Usar datos mock en formato de API
      const players: Player[] = mockApiPlayers.map((apiPlayer, index) => this.mapApiPlayerToPlayer(apiPlayer, index))
      const searchedPlayerMock = createSearchedPlayerMock(playerName)
      const searchedPlayer = this.mapApiPlayerToPlayer(searchedPlayerMock, 0)

      return {
        players: players,
        searchedPlayer: searchedPlayer,
        isFromApi: false,
        message: `Los jugadores similares a "${playerName}" son: ${players.map((p) => p.name).join(", ")} (datos mock)`,
      }
    }
  }
}
