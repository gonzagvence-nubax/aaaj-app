# 🏆 Argentinos Juniors Scoutly

Sistema de análisis de jugadores con IA para Argentinos Juniors.

## 🚀 Inicio Rápido con Docker

### Prerrequisitos
- Docker y Docker Compose instalados
- Tu API corriendo en `localhost:8038`

### Opción 1: Script de inicio (Recomendado)
\`\`\`bash
# Hacer ejecutable
chmod +x start.sh

# Iniciar aplicación
./start.sh up

# Ver logs
./start.sh logs

# Detener
./start.sh down
\`\`\`

### Opción 2: NPM Scripts
\`\`\`bash
# Iniciar
npm run docker:up

# Detener
npm run docker:down

# Ver logs
npm run docker:logs
\`\`\`

### Opción 3: Make
\`\`\`bash
# Iniciar
make up

# Ver logs
make logs

# Detener
make down
\`\`\`

### Opción 4: Docker Compose directo
\`\`\`bash
# Iniciar
docker-compose up --build

# Detener
docker-compose down
\`\`\`

## 🌐 Acceso

- **Aplicación**: http://localhost:3000
- **Tu API**: http://localhost:8038 (debe estar corriendo)

## 🔧 Comandos Útiles

\`\`\`bash
# Ver logs en tiempo real
./start.sh logs

# Acceder al contenedor
./start.sh shell

# Limpiar todo
./start.sh clean

# Reconstruir imagen
./start.sh build
\`\`\`

## 📁 Estructura del Proyecto

\`\`\`
argentinos-scoutly/
├── app/                    # Páginas de Next.js
├── components/             # Componentes React
├── services/              # Servicios de API
├── public/                # Archivos estáticos
├── docker-compose.yml     # Configuración Docker
├── Dockerfile            # Imagen Docker
├── start.sh              # Script de inicio
└── Makefile              # Comandos Make
\`\`\`

## 🐛 Solución de Problemas

### La aplicación no se conecta a la API
- Verifica que tu API esté corriendo en `localhost:8038`
- Revisa los logs: `./start.sh logs`

### Error de dependencias
- Limpia y reconstruye: `./start.sh clean && ./start.sh build`

### Puerto ocupado
- Cambia el puerto en `docker-compose.yml` si el 3000 está ocupado
\`\`\`

Archivo de variables de entorno:
