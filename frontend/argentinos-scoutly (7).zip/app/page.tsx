"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Send, User, BarChart3, Loader2, Wifi, WifiOff, AlertCircle } from "lucide-react"
import Image from "next/image"
import { PlayerRadar } from "@/components/player-radar"
import { ApiService } from "@/services/apiService"

interface PlayerStats {
  goles_90: number
  regates_realizados_pct: number
  pases_90: number
  asistencias_90: number
  duelos_aereos_ganados_pct: number
  goles_cabeza_90: number
  duelos_atacantes_ganados_pct: number
}

interface Player {
  id: number
  name: string
  position: string
  age: number
  goals: number
  assists: number
  matches: number
  rating: number
  marketValue: string
  team: string
  valor_mercado: number
  stats: PlayerStats
}

interface Message {
  id: number
  text: string
  isUser: boolean
  players?: Player[]
  searchedPlayer?: Player | null
  isLoading?: boolean
  isFromApi?: boolean
}

export default function ArgentinosScoutly() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "¡Hola! Soy tu asistente de scouting de Argentinos Juniors. Busca jugadores similares escribiendo un nombre.",
      isUser: false,
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [apiStatus, setApiStatus] = useState<"checking" | "online" | "offline">("checking")

  // Helper function to safely format numbers
  const safeToFixed = (value: any, decimals = 2): string => {
    const num = Number(value)
    return isNaN(num) ? "0.00" : num.toFixed(decimals)
  }

  // Verificar estado de la API al cargar
  useEffect(() => {
    const checkApi = async () => {
      const isOnline = await ApiService.checkApiHealth()
      setApiStatus(isOnline ? "online" : "offline")
    }

    checkApi()

    // Verificar cada 30 segundos
    const interval = setInterval(checkApi, 30000)
    return () => clearInterval(interval)
  }, [])

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now(),
      text: inputValue,
      isUser: true,
    }

    const loadingMessage: Message = {
      id: Date.now() + 1,
      text: apiStatus === "online" ? "Buscando jugadores similares..." : "Procesando con datos locales...",
      isUser: false,
      isLoading: true,
    }

    setMessages((prev) => [...prev, userMessage, loadingMessage])
    const searchTerm = inputValue
    setInputValue("")
    setIsLoading(true)

    try {
      const response = await ApiService.searchPlayers(searchTerm)

      const botResponse: Message = {
        id: Date.now() + 1,
        text: response.message,
        isUser: false,
        players: response.players,
        searchedPlayer: response.searchedPlayer,
        isFromApi: response.isFromApi,
      }

      setMessages((prev) => prev.map((msg) => (msg.id === loadingMessage.id ? botResponse : msg)))
    } catch (error) {
      console.error("Error searching players:", error)

      const errorMessage: Message = {
        id: Date.now() + 1,
        text: "Lo siento, hubo un error al procesar tu solicitud. Por favor intenta nuevamente.",
        isUser: false,
      }

      setMessages((prev) => prev.map((msg) => (msg.id === loadingMessage.id ? errorMessage : msg)))
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !isLoading) {
      handleSendMessage()
    }
  }

  const getStatusColor = () => {
    switch (apiStatus) {
      case "online":
        return "bg-green-400"
      case "offline":
        return "bg-red-400"
      case "checking":
        return "bg-yellow-400"
    }
  }

  const getStatusText = () => {
    switch (apiStatus) {
      case "online":
        return "API Conectada"
      case "offline":
        return "API Offline"
      case "checking":
        return "Verificando..."
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-100">
      {/* Header */}
      <header className="bg-gradient-to-r from-red-600 to-red-700 text-white shadow-2xl">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <div className="relative">
                <Image
                  src="/argentinos-logo.png"
                  alt="Argentinos Juniors Logo"
                  width={70}
                  height={70}
                  className="rounded-full bg-white p-2 shadow-lg"
                />
                <div
                  className={`absolute -top-1 -right-1 w-4 h-4 ${getStatusColor()} rounded-full border-2 border-white`}
                ></div>
              </div>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-white to-red-100 bg-clip-text text-transparent">
                  Argentinos Juniors Scoutly
                </h1>
                <p className="text-red-100 text-lg">Sistema de análisis de jugadores con IA</p>
              </div>
            </div>

            {/* Status indicator */}
            <div className="flex items-center gap-2 bg-white/10 px-3 py-2 rounded-lg">
              {apiStatus === "online" ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
              <span className="text-sm">{getStatusText()}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Chat Container */}
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Card className="h-[700px] flex flex-col border-red-200 shadow-2xl backdrop-blur-sm bg-white/95">
          <CardHeader className="bg-gradient-to-r from-red-50 to-red-100 border-b border-red-200">
            <CardTitle className="flex items-center gap-2 text-red-800">
              <BarChart3 className="w-5 h-5" />
              Hablá con nuestro Scout entrenado con IA!
            </CardTitle>
          </CardHeader>

          {/* Messages Area */}
          <CardContent className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.isUser ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[90%] ${message.isUser ? "order-2" : "order-1"}`}>
                  <div className={`flex items-start gap-2 ${message.isUser ? "flex-row-reverse" : "flex-row"}`}>
                    <div className="w-8 h-8 rounded-full overflow-hidden">
                      {message.isUser ? (
                        <div className="w-full h-full bg-red-600 flex items-center justify-center">
                          <User className="w-4 h-4 text-white" />
                        </div>
                      ) : (
                        <Image
                          src="/scout-avatar.png"
                          alt="Scout AI"
                          width={32}
                          height={32}
                          className="w-full h-full object-cover"
                        />
                      )}
                    </div>
                    <div
                      className={`rounded-lg px-4 py-2 ${
                        message.isUser ? "bg-red-600 text-white" : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      <p>{message.text}</p>
                      {message.isLoading && (
                        <div className="flex items-center gap-2 mt-2">
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span className="text-sm">
                            {apiStatus === "online" ? "Consultando API..." : "Usando datos locales..."}
                          </span>
                        </div>
                      )}

                      {/* Indicador de fuente de datos */}
                      {message.players && message.isFromApi !== undefined && (
                        <div className="flex items-center gap-1 mt-2">
                          {message.isFromApi ? (
                            <div className="flex items-center gap-1 text-xs text-green-600">
                              <Wifi className="w-3 h-3" />
                              <span>Datos de API</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1 text-xs text-orange-600">
                              <AlertCircle className="w-3 h-3" />
                              <span>Datos Mock</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Player Stats Cards */}
                  {message.players && (
                    <div className="mt-3 ml-10 space-y-4">
                      {message.players.map((player) => (
                        <Card key={player.id} className="border-red-200">
                          <CardHeader className="pb-3">
                            <CardTitle className="text-lg text-red-800">{player.name}</CardTitle>
                            <p className="text-sm text-gray-600">
                              {player.team} • Rating: {player.rating}
                            </p>
                          </CardHeader>
                          <CardContent className="pt-0">
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                              {/* Estadísticas básicas */}
                              <div>
                                <h4 className="font-semibold text-red-800 mb-3">Estadísticas de la API</h4>
                                <div className="grid grid-cols-2 gap-3 text-sm">
                                  <div className="text-center">
                                    <div className="text-lg font-bold text-red-600">
                                      {safeToFixed(player.stats?.goles_90, 2)}
                                    </div>
                                    <div className="text-xs text-gray-600">Goles/90min</div>
                                  </div>
                                  <div className="text-center">
                                    <div className="text-lg font-bold text-red-600">
                                      {safeToFixed(player.stats?.asistencias_90, 2)}
                                    </div>
                                    <div className="text-xs text-gray-600">Asistencias/90min</div>
                                  </div>
                                  <div className="text-center">
                                    <div className="text-lg font-bold text-red-600">
                                      {safeToFixed(player.stats?.pases_90, 1)}
                                    </div>
                                    <div className="text-xs text-gray-600">Pases/90min</div>
                                  </div>
                                  <div className="text-center">
                                    <div className="text-lg font-bold text-red-600">
                                      {safeToFixed(player.stats?.regates_realizados_pct, 1)}%
                                    </div>
                                    <div className="text-xs text-gray-600">Regates</div>
                                  </div>
                                  <div className="text-center">
                                    <div className="text-lg font-bold text-red-600">
                                      {safeToFixed(player.stats?.duelos_aereos_ganados_pct, 1)}%
                                    </div>
                                    <div className="text-xs text-gray-600">Duelos Aéreos</div>
                                  </div>
                                  <div className="text-center">
                                    <div className="text-lg font-bold text-red-600">
                                      {safeToFixed(player.stats?.goles_cabeza_90, 2)}
                                    </div>
                                    <div className="text-xs text-gray-600">Goles Cabeza/90min</div>
                                  </div>
                                  <div className="text-center">
                                    <div className="text-lg font-bold text-red-600">
                                      {safeToFixed(player.stats?.duelos_atacantes_ganados_pct, 1)}%
                                    </div>
                                    <div className="text-xs text-gray-600">Duelos Ataque</div>
                                  </div>
                                </div>
                                <div className="text-center mt-4 pt-4 border-t border-gray-200">
                                  <div className="text-xl font-bold text-red-600">{player.marketValue}</div>
                                  <div className="text-sm text-gray-600">Valor de Mercado</div>
                                </div>
                              </div>

                              {/* Radar de habilidades con comparación */}
                              <div>
                                <h4 className="font-semibold text-red-800 mb-3">
                                  Comparación vs {message.searchedPlayer?.name || "Referencia"}
                                </h4>
                                {player.stats && (
                                  <PlayerRadar
                                    stats={player.stats}
                                    playerName={player.name}
                                    comparisonStats={message.searchedPlayer?.stats}
                                    comparisonName={message.searchedPlayer?.name || "Referencia"}
                                  />
                                )}
                                <div className="mt-2 text-xs text-gray-500 text-center">
                                  <span className="inline-block w-3 h-3 bg-red-600 mr-1"></span>
                                  {player.name} vs
                                  <span className="inline-block w-3 h-3 bg-blue-600 ml-1 mr-1"></span>
                                  {message.searchedPlayer?.name || "Referencia"}
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </CardContent>

          {/* Input Area */}
          <div className="border-t border-red-200 p-4 bg-red-50">
            <div className="flex gap-2">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Busca un jugador similar a..."
                className="flex-1 border-red-200 focus:border-red-400"
                disabled={isLoading}
              />
              <Button
                onClick={handleSendMessage}
                className="bg-red-600 hover:bg-red-700 text-white"
                disabled={isLoading}
              >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
