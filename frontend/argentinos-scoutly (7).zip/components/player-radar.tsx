"use client"

import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Legend } from "recharts"

interface PlayerStats {
  goles_90: number
  regates_realizados_pct: number
  pases_90: number
  asistencias_90: number
  duelos_aereos_ganados_pct: number
  goles_cabeza_90: number
  duelos_atacantes_ganados_pct: number
}

interface PlayerRadarProps {
  stats: PlayerStats
  playerName: string
  comparisonStats?: PlayerStats
  comparisonName?: string
}

export function PlayerRadar({ stats, playerName, comparisonStats, comparisonName }: PlayerRadarProps) {
  // Función para normalizar valores a escala 0-100 para el radar
  const normalizeValue = (value: number, key: string): number => {
    switch (key) {
      case "goles_90":
        // Normalizar goles por 90 min (0-1 = 0-100)
        return Math.min(100, Math.max(0, value * 100))
      case "regates_realizados_pct":
        // Ya está en porcentaje
        return Math.min(100, Math.max(0, value))
      case "pases_90":
        // Normalizar pases por 90 min (0-100 = 0-100)
        return Math.min(100, Math.max(0, value))
      case "asistencias_90":
        // Normalizar asistencias por 90 min (0-1 = 0-100)
        return Math.min(100, Math.max(0, value * 100))
      case "duelos_aereos_ganados_pct":
        // Ya está en porcentaje
        return Math.min(100, Math.max(0, value))
      case "goles_cabeza_90":
        // Normalizar goles de cabeza por 90 min (0-0.5 = 0-100)
        return Math.min(100, Math.max(0, value * 200))
      case "duelos_atacantes_ganados_pct":
        // Ya está en porcentaje
        return Math.min(100, Math.max(0, value))
      default:
        return value
    }
  }

  // Función para obtener etiquetas más legibles
  const getLabel = (key: string): string => {
    switch (key) {
      case "goles_90":
        return "Goles/90min"
      case "regates_realizados_pct":
        return "Regates %"
      case "pases_90":
        return "Pases/90min"
      case "asistencias_90":
        return "Asistencias/90min"
      case "duelos_aereos_ganados_pct":
        return "Duelos Aéreos %"
      case "goles_cabeza_90":
        return "Goles Cabeza/90min"
      case "duelos_atacantes_ganados_pct":
        return "Duelos Ataque %"
      default:
        return key
    }
  }

  const data = Object.keys(stats).map((key) => ({
    subject: getLabel(key),
    [playerName]: Math.round(normalizeValue(stats[key as keyof PlayerStats], key)),
    ...(comparisonStats && {
      [comparisonName || "Referencia"]: Math.round(normalizeValue(comparisonStats[key as keyof PlayerStats], key)),
    }),
    fullMark: 100,
  }))

  return (
    <div className="w-full h-80">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={data} margin={{ top: 20, right: 30, bottom: 20, left: 30 }}>
          <PolarGrid />
          <PolarAngleAxis dataKey="subject" className="text-xs" />
          <PolarRadiusAxis angle={90} domain={[0, 100]} className="text-xs" tick={false} />
          <Radar
            name={playerName}
            dataKey={playerName}
            stroke="#dc2626"
            fill="#dc2626"
            fillOpacity={0.3}
            strokeWidth={2}
          />
          {comparisonStats && (
            <Radar
              name={comparisonName || "Referencia"}
              dataKey={comparisonName || "Referencia"}
              stroke="#2563eb"
              fill="#2563eb"
              fillOpacity={0.2}
              strokeWidth={2}
              strokeDasharray="5 5"
            />
          )}
          <Legend />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  )
}
