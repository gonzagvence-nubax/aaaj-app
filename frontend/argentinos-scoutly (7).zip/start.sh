#!/bin/bash

echo "🚀 Argentinos Scoutly - Modo Desarrollo"

# Verificar si Docker está corriendo
if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker no está corriendo. Por favor inicia Docker primero."
    exit 1
fi

# Función para mostrar ayuda
show_help() {
    echo "Uso: ./start.sh [OPCIÓN]"
    echo ""
    echo "Opciones:"
    echo "  up         Iniciar la aplicación"
    echo "  down       Detener la aplicación"
    echo "  build      Reconstruir la imagen"
    echo "  clean      Limpiar contenedores e imágenes"
    echo "  logs       Ver logs en tiempo real"
    echo "  shell      Acceder al contenedor"
    echo "  help       Mostrar esta ayuda"
    echo ""
}

# Verificar argumentos
case "$1" in
    "up"|"")
        echo "🔧 Iniciando aplicación en modo desarrollo..."
        docker-compose up --build
        ;;
    "down")
        echo "🛑 Deteniendo aplicación..."
        docker-compose down
        ;;
    "build")
        echo "🔨 Reconstruyendo imagen..."
        docker-compose build --no-cache
        ;;
    "clean")
        echo "🧹 Limpiando contenedores e imágenes..."
        docker-compose down -v --rmi all
        docker system prune -f
        ;;
    "logs")
        echo "📋 Mostrando logs..."
        docker-compose logs -f
        ;;
    "shell")
        echo "🐚 Accediendo al contenedor..."
        docker exec -it argentinos-scoutly-dev sh
        ;;
    "help")
        show_help
        ;;
    *)
        echo "❌ Opción no válida: $1"
        show_help
        exit 1
        ;;
esac
